import os, discord, random
from dotenv import load_dotenv
from discord.ext import commands

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')
GUILD = os.getenv('DISCORD_GUILD')

intents = discord.Intents().all()
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    guild = discord.utils.get(bot.guilds)
    
    print(f'{bot.user.name} is connected to {guild.name}.')
    
    print(f'Server Members ({len(guild.members)}):')
    for member in guild.members:
        print(f'- {member.name}')

# @bot.event # Responds to if the bot is pinged
# async def on_message(message):
#     if bot.user.mentioned_in(message):
#         await message.channel.send("Shut up I don't care", reference = message)
#     else:
#         return

@bot.command(name='roll', help='Rolls dice with the format xdy+z')
async def dieroll(ctx, *, content):
    content.replace(" ","")
    number, sides = content.split("d")
    if sides.isnumeric():
        modifier = 0
    else:
        sides, modifier = sides.split("+")
    modifier = int(modifier)
    number = int(number)
    sides = int(sides)
    rolls = []
    for i in range(number):
        rolls.append(random.randint(1,sides))
    total = sum(rolls)
    if modifier == 0:
        await ctx.reply(f'**Result: {total}** {rolls}') # Adds  *{ctx.message.author.mention} rolled{ctx.message.content.replace("!roll","")}:* \n
    else:
        await ctx.reply(f'**Result: {total + modifier}** `{rolls} (+{modifier})`')
    
@bot.command(name='dndstats', help='Rolls ability scores for D&D 5e using the 4d6 drop lowest method')
async def fortysix(ctx):
    results = ""
    attributes = [0,0,0,0,0,0]
    for i in range(0,6):
        dice = [0,0,0,0]
        for p in range(0,4):
            dice[p] = random.randint(1,6)
        dice.sort(reverse=True)
        results += f'`{dice}` Result: `{sum(dice) - min(dice)}`\n'
        dice.remove(min(dice))
        attributes[i] = sum(dice)
    attributes.sort(reverse=True)
    await ctx.reply(f'**Ability Scores: {attributes}**\n{results}')

@bot.command(name='fireball', help='fireball wins again')
async def fireroll(ctx):
    rolls = []
    for i in range (1,8):
        rolls.append(random.randint(1,6))
    total = sum(rolls)
    # I still want this to display without the link text but what fucking ever
    await ctx.reply(f'**Result: {total}** `{rolls}`' + ' https://tenor.com/view/xptolevel3-xptolvl3-jacob-budz-jacob-budz-gif-27231246')

@bot.command(name='dndidea', description='Generates a random race and class for your next 5e character.')
async def cherry(ctx):
    races = ['Dragonborn','Dwarf','Elf','Gnome','Half-Elf','Halfling','Half-Orc','Human','Tiefling']
    classes = ['Barbarian','Bard','Cleric','Druid','Fighter','Monk','Paladin','Ranger','Rogue','Sorcerer','Warlock','Wizard']
    charrace = races[random.randint(0,len(races) - 1)]
    charclass = classes[random.randint(0,len(classes) - 1)]
    if charrace == 'Dragonborn':
        subraces = ['Black','Blue','Brass','Bronze','Copper','Gold','Green','Red','Silver','White']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    elif charrace == 'Dwarf':
        subraces = ['Hill','Mountain','Duergar']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    elif charrace == 'Elf':
        subraces = ['High','Wood','Drow','Sea']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    elif charrace == 'Gnome':
        subraces = ['Rock','Forest','Deep']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    elif charrace == 'Half-Elf':
        subraces = ['High','Wood','Drow']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    elif charrace == 'Halfling':
        subraces = ['Lightfoot','Stout']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    elif charrace == 'Half-Orc':
        subraces = ['']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    elif charrace == 'Human':
        subraces = ['','Variant']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    else: # Tiefling
        subraces = ['']
        charsubrace = subraces[random.randint(0,len(subraces) - 1)]
    
    if charsubrace == '':
        await ctx.reply(f'You should play a {charrace} {charclass}!')
    else:
        await ctx.reply(f'You should play a {charsubrace} {charrace} {charclass}!')    

@bot.command(name='vote', description='Place phrases in a row separated with commas to create a tally voting system with a maximum of six items')
async def makepoll(ctx, *, content):
    choices = ''
    commas = 0
    for character in content:
        if character == ',':
            commas += 1
    if commas == 0:
        await ctx.reply("You have to have more than one choice to take a vote on them. God damn")
    while ',' in content:
        item, content = content.partition(',')
        choices += item.lstrip(' ') + '\n'
    choices += content.lstrip(' ') + '\n'
    await ctx.send(choices)
        

bot.run(TOKEN)