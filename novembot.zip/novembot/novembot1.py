import os, discord, random
from dotenv import load_dotenv
from discord.ext import commands

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')
GUILD = os.getenv('DISCORD_GUILD')

intents = discord.Intents().all()
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    guild = discord.utils.get(bot.guilds)
    
    print(
        f'{bot.user.name} is connected to {guild.name}.'
    )
    
    print(f'Server Members ({len(guild.members)}):')
    for member in guild.members:
        print(f'- {member.name}')
    
@bot.command(name='bot', help='says bot to you. what else would it do')
async def reply(ctx):
    response = "BOT!!!"
    await ctx.send(response)
    
@bot.command(name='poop', help='gives you a random word for poop')
async def poopy(ctx):
    pooplist = ['poop', 'shit', 'diarrhea']
    response = random.choice(pooplist)
    await ctx.send(response)
    
@bot.command(name='roll', help='rolls your fucking die')
async def dieroll(ctx, *, content): # number: int, sides: int, modifier:int = None
    content.replace(" ","")
    number, sides = content.split("d")
    if sides.isnumeric():
        modifier = 0
    else:
        sides, modifier = sides.split("+")
    modifier = int(modifier)
    number = int(number)
    sides = int(sides)
    total = 0
    rolls = []
    for i in range(number):
        rolls.append(random.randint(1,sides))
    total = sum(rolls)
    if modifier == 0:
        response = f'**Result: {total}** {rolls}'
    else:
        total += int(modifier)
        response = f'**Result: {total}** `{rolls} (+{modifier})`'
    await ctx.send(response)
    
@bot.command(name='dndstats', help='rolls you a 4d6 drop lowest')
async def fortysix(ctx):
    
    attributes = [0,0,0,0,0,0]
    for i in range(0,6):
        dice = [0,0,0,0]
        for p in range(0,4):
            dice[p] = random.randint(1,6)
        dice.remove(min(dice))
        threedice = sum(dice)
        attributes[i] = threedice
    
    attributes.sort(reverse=True)
    response = attributes
    await ctx.send(response)

bot.run(TOKEN)